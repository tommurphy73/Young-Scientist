These files are from the [@NordicSemiconductor](https://github.com/NordicSemiconductor)[ble-sdk-arduino](https://github.com/NordicSemiconductor/ble-sdk-arduino).

Some file have been slightly modified.