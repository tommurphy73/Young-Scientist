// This file allows the SmartEverything Basic examples to appear in the Arduino IDE 1.6.6 File > Examples menu.
