/*
 * ndef.h
 *
 * Created: 3/29/2015 12:59:49 PM
 * by Mik (smkk@amel-tech.com)
 *
 */ 


#ifndef NDEF_H_
#define NDEF_H_


#include "../../SmeNfc.h"


bool NT3HwriteRecord(const NDEFDataStr *data);


#endif /* NDEF_H_ */
