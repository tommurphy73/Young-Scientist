ArduinoRC-Car
=============
Arduino power rc car using the Red Bear BLE Shield for Arduino Uno. 
This project is derived from the simple controls sample project from Red Bear. 
Libs are used from Red Bear and Arduino. 
