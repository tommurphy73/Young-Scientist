#ifndef NORDIC_NRF8001_H_
#define NORDIC_NRF8001_H_

// It is nothing here.

#endif /* NORDIC_NRF8001_H_ */